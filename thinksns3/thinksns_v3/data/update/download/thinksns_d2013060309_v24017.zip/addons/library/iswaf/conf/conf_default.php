<?php

return array('defences'=>array(
				'callback_xss'=>'On',
				'upload'=>'On',
				'inject'=>'On',	
				'filemode'=>'On',
				'webshell'=>'On',
				'server_args'=>'On',
				'webserver'=>'On',
				'hotfixs'=>'On',
				)
		);
					 
?>