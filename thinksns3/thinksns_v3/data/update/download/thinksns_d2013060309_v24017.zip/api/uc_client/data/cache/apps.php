<?php
$_CACHE['apps'] = array (
  2 => 
  array (
    'appid' => '2',
    'type' => 'OTHER',
    'name' => 'ts',
    'url' => 'http://ts',
    'ip' => '127.0.0.1',
    'viewprourl' => '',
    'apifilename' => 'uc_client/uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[]]></item>
</root>',
    'allowips' => '',
  ),
);

?>