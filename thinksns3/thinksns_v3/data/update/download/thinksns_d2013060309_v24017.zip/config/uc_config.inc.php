<?php
define('UC_SYNC', 0);
